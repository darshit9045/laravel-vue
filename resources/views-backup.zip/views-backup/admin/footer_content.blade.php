@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')

@stop

@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Footer</h2>
            </div>

        </div>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    @if ($message = Session::get('success'))
        <div class="alert alert-info btn-sm" role="alert">
            <p>{{ $message }}</p>
        </div>
    @endif

    @php
        if (get_setting('footer_content')) {
            $hc = json_decode(get_setting('footer_content'));
        } else {
            $hc = false;
        }
    @endphp
    <div class="column col-2">
        @foreach($menus AS $mn)
            @if($hc && in_array($mn->id, $hc->menu)) @continue @endif
            <div class="box" draggable="true">{{$mn->title}}<input type="hidden" name="menu_order[]" value="{{$mn->id}}" ></div>
        @endforeach
    </div>
    <form action="{{ route('setting.footercontent.store') }}" method="POST" id="settingForm">
        @csrf
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Drop here footer menu:</strong>
                <div class="input-group mb-2">
                    <div class="column col-2 column-result">
                        @foreach($menus AS $mn)
                            @if($hc && in_array($mn->id, $hc->menu))
                                <div class="box" draggable="true">{{$mn->title}}<input type="hidden" name="menu_order[]" value="{{$mn->id}}" ></div>
                            @endif
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">

                <div class="card">
                    <div class="card-header">
                        <strong>Address:</strong>
                    </div>
                    <div class="card-body">
                        <textarea id="address" class="text-area" name="address">{!!  $hc?$hc->address:''  !!}</textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">

                <div class="card">
                    <div class="card-header">
                        <strong>Copyright:</strong>
                    </div>
                    <div class="card-body">
                        <textarea id="copyright" class="text-area" name="copyright">{!!  $hc?$hc->copyright:''  !!}</textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xs-6 col-sm-12 col-md-6">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
{{--    <script src="{{ asset('node_modules/tinymce/tinymce.min.js') }}"></script>--}}

    <script src="https://cdn.tiny.cloud/1/r9fqtfs34xc7rgtb3qv0akebtmizyxkss0wsl59bvdbiev09/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
        tinymce.init({
            selector: 'textarea',
            plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount code image',
            toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | code | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat | styleselect',
            tinycomments_mode: 'embedded',
            tinycomments_author: 'Author name',
            mergetags_list: [
                { value: 'First.Name', title: 'First Name' },
                { value: 'Email', title: 'Email' },
            ]
        });
    </script>

@stop
@section('css')
    <style> .column { height: 250px; background-color: lightgray; display: inline-block; vertical-align: top; margin-right: 10px; overflow-y: scroll; } .box { height: 50px; background-color: #007bff; color: white; text-align: center; line-height: 50px; margin-bottom: 10px; border-radius: 5px; } </style>
@stop

@section('js')
    <script>
        // JavaScript code for drag and drop functionality
        var dragItem = null;
        document.addEventListener("dragstart", function(event) {
            // Save reference to the element being dragged
            dragItem = event.target;
        });
        document.addEventListener("dragover", function(event) {
            // Allow drops on element
            event.preventDefault();
        });
        document.addEventListener("drop", function(event) {
            // Only handle drops on columns
            if (event.target.classList.contains("column")) {
                // Append dragged element to column
                event.target.appendChild(dragItem);
            }
        });
    </script>
@stop
