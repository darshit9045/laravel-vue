@section('css')
    <link rel="stylesheet" href="{{ asset('css/custom.css') }}" >
    <link rel="stylesheet" href="{{asset('/css/admin_custom.css')}}">
@stop
@section('js')
    <script src="{{asset('/js/select2.min.js')}}" /></script>
    <script src="{{asset('/js/custom.js')}}"></script>

@stop
