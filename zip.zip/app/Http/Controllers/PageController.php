<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Page;
use App\Models\User;
use App\Http\View;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;

class PageController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $pages = Page::paginate(20);
        return view('admin.index', compact('pages'));
        // ->with('i', (request()->input('page', 1) - 1) * 20)
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required',
            'slug' => [
                'unique:pages,slug'
            ],
            'body' => 'required',
            'feature_image' => 'file|image|max:2048'
        ]);

        $input = $request->all();
        if (empty($request->slug)) {
            $slug = Str::slug($request->name);
            $validator = Validator::make(['slug' => $slug], [
                'slug' => [
                    'unique:pages,slug'
                ]
            ]);
            if ($validator->fails()) {
                $slug = $request->slug = Str::slug($request->name) . '-' . time();
            }
            $input['slug'] = $slug;
        }

        if ($image = $request->file('feature_image')) {
            $destinationPath = public_path('images/');
            $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $input['feature_image'] = "$profileImage";
        }
        Page::create($input);
        return redirect()->route('pages.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(Page $page)
    {
        return view('admin.show', compact('page'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Page $page)
    {
        return view('admin.edit', compact('page'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $input = $request->all();
        if ($image = $request->file('feature_image')) {
            $destinationPath = public_path('images/');
            $profileImage = date('YmdHis') . "." . $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $input['feature_image'] = "$profileImage";
        } else {
            unset($input['feature_image']);
        }

        $page = Page::find($id);
        $page->update($input);

        return redirect()->route('pages.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Page $page)
    {
        $page->update(['status'=>'Trash']);
        return back()->with('success', 'Product deleted successfully');
    }

    public function trashed()
    {
        $pages = Page::where('status', 'Trash')->paginate(20);
        return view('admin.trashed', compact('pages'));
    }

    public function trashedDelete($id)
    {
        Page::where('id', $id)->delete();
        return back()->with('success', 'Pages deleted successfully.');
    }

    public function public()
    {
        $pages = Page::where('status', 'public')
            ->orderBy('created_at', 'desc')
            ->paginate(20);
        return view('admin.public', compact('pages'));
    }

    public function draf(Request $request)
    {
        $pages = Page::where('status', 'Draft')
            ->orderBy('created_at', 'desc')
            ->paginate(20);
        return view('admin.draf', compact('pages'));
    }

    public function updateStatus(Request $request)
    {
        $validated = $request->validate([
            'status' => 'required',
            'selecte_page' => 'required',
        ]);
        $pages = Page::whereIn('id', explode(',', $request->selecte_page))->update(['status' => $request->status]);

        return redirect()->back()->with('success', 'Pages status updated successfully.');
    }

    public  function search(Request $request) {

        $pages = Page::where('name', 'like', '%'.$request->search.'%')->orWhere('slug', 'like', '%'.$request->search.'%')->paginate(20);
        $search = $request->search;
        return view('admin.index', compact('pages', 'search'));
    }

}
